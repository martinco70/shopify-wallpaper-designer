# Shared

Gemeinsame Ressourcen und Code für Backend und Frontend.
