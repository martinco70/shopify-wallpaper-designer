// ...existing code...
// ...existing code...
require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const app = express();
const { execFile } = require('child_process');
const pathResolve = (...p) => path.join(...p);
const sharp = require('sharp');
function getMagickCmd() {
  const fs = require('fs');
  const { spawnSync } = require('child_process');
  // Non-Windows: use override or 'magick' from PATH
  if (process.platform !== 'win32') {
    return process.env.MAGICK_PATH || 'magick';
  }

  // 1) Respect explicit override
  const fromEnv = process.env.MAGICK_PATH;
  if (fromEnv && fs.existsSync(fromEnv)) return fromEnv;

  // 2) Try to locate via 'where magick'
  try {
    const out = spawnSync('where', ['magick'], { encoding: 'utf8', windowsHide: true });
    const cand = String(out.stdout || '')
      .split(/\r?\n/)
      .map(s => s.trim())
      .filter(s => s && /magick\.exe$/i.test(s));
    if (cand.length && fs.existsSync(cand[0])) return cand[0];
  } catch {}

  // 3) Search under Program Files for ImageMagick*/magick.exe (first match)
  const bases = ['C:\\Program Files', 'C:\\Program Files (x86)'];
  for (const base of bases) {
    try {
      const entries = fs.readdirSync(base, { withFileTypes: true });
      for (const e of entries) {
        if (!e.isDirectory()) continue;
        if (!/^ImageMagick/i.test(e.name)) continue;
        const full = path.join(base, e.name, 'magick.exe');
        try { if (fs.existsSync(full)) return full; } catch {}
      }
    } catch {}
  }

  // 4) Fallback to PATH name
  return 'magick';
}
const magickCmd = getMagickCmd();
// Resolve Ghostscript command (Windows) so ImageMagick can delegate PDFs/EPS reliably
function getGhostscriptCmd() {
  const fs = require('fs');
  const { spawnSync } = require('child_process');
  if (process.platform !== 'win32') {
    return process.env.GS_PATH || 'gs';
  }
  const fromEnv = process.env.GS_PATH;
  if (fromEnv && fs.existsSync(fromEnv)) return fromEnv;
  try {
    const out = spawnSync('where', ['gswin64c'], { encoding: 'utf8', windowsHide: true });
    const cand = String(out.stdout || '')
      .split(/\r?\n/)
      .map(s => s.trim())
      .filter(s => s && /gswin64c\.exe$/i.test(s));
    if (cand.length && fs.existsSync(cand[0])) return cand[0];
  } catch {}
  const bases = ['C:\\Program Files\\gs', 'C:\\Program Files (x86)\\gs'];
  for (const base of bases) {
    try {
      const entries = fs.readdirSync(base, { withFileTypes: true })
        .filter(e => e.isDirectory() && /^gs\d+/i.test(e.name))
        .sort((a,b) => b.name.localeCompare(a.name));
      for (const e of entries) {
        const exe = path.join(base, e.name, 'bin', 'gswin64c.exe');
        try { if (fs.existsSync(exe)) return exe; } catch {}
      }
    } catch {}
  }
  return 'gswin64c';
}
const ghostscriptCmd = getGhostscriptCmd();
// Optional: log which ImageMagick command was resolved (helps on Windows)
try { console.log('[init] Using ImageMagick command:', magickCmd); } catch {}
console.log('[init] Using ImageMagick command:', magickCmd);
// Verify resolved path exists on disk (Windows absolute path) to avoid false "missing" classification
try {
  if (path.isAbsolute(magickCmd) && !fs.existsSync(magickCmd)) {
    console.warn('[init] Warning: Resolved ImageMagick path does not exist on disk:', magickCmd);
  }
} catch {}
try { console.log('[init] Using Ghostscript command:', ghostscriptCmd); } catch {}
app.use(cors({
  origin: 'http://localhost:8080',
  credentials: true
}));
// JSON-Parser früh aktivieren, damit alle Router/Endpoints Body erhalten
app.use(express.json());

const Shopify = require('shopify-api-node');
function normalizeShopName(input) {
  if (!input) return 'aahoma';
  let s = String(input).trim().toLowerCase();
  s = s.replace(/^https?:\/\//, '');
  s = s.replace(/\.myshopify\.com.*/, '');
  s = s.replace(/\/$/, '');
  return s;
}
const shopName = normalizeShopName(process.env.SHOPIFY_SHOP || 'aahoma');
const accessToken = process.env.SHOPIFY_ACCESS_TOKEN;
const apiKey = process.env.SHOPIFY_API_KEY || 'c696c79546485248af4b6c088cf62dc5';
const password = process.env.SHOPIFY_PASSWORD || '575337c2de182680fe2179ea80480dd5';
const shopify = new Shopify(
  accessToken
    ? { shopName, accessToken }
    : { shopName, apiKey, password }
);

// Endpunkt: Alle Produkte und Varianten mit SKUs und Preisen auflisten
app.get('/shopify/skus', async (req, res) => {
  try {
    const products = await shopify.product.list();
    const result = products.map(product => ({
      productId: product.id,
      title: product.title,
      variants: product.variants.map(variant => ({
        variantId: variant.id,
        sku: variant.sku,
        price: variant.price
      }))
    }));
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Fehler beim Abrufen der SKUs', details: err.message });
  }
});

// Shopify Health-Check: prüft, ob API erreichbar und Credentials gültig sind
app.get('/shopify/health', async (req, res) => {
  try {
    const shop = await shopify.shop.get();
    return res.json({ ok: true, shop: { name: shop.name, domain: shop.myshopify_domain } });
  } catch (err) {
    const status = err.statusCode || err.status || 500;
    const details = err?.response?.body || err?.body || undefined;
    return res.status(500).json({ ok: false, error: err.message, status, details });
  }
});

// Preis-Endpunkt für Material-SKU
app.get('/price/:sku', async (req, res) => {
  const sku = req.params.sku;
  try {
    // 1) REST: Direkter Variant-Lookup per SKU (schnellste Option)
    try {
      const variants = await shopify.productVariant.list({ sku, limit: 1 });
      if (Array.isArray(variants) && variants.length && variants[0].price != null) {
        return res.json({ price: Number(variants[0].price) });
      }
    } catch (e) {
      // Ignorieren und weiter mit Fallbacks (z.B. falls API 404/422 liefert)
    }

    // 2) Fallback: REST-Scan c 3d 250 Produkte (erste Seite)
    let price = null;
    try {
      const products = await shopify.product.list({ limit: 250, fields: 'id,title,variants' });
      for (const product of products) {
        if (product.variants && product.variants.length) {
          const v = product.variants.find(v => v.sku === sku);
          if (v) { price = v.price; break; }
        }
      }
    } catch (e) {
      // ignorieren; lokaler Fallback folgt
    }
    if (price != null) {
      return res.json({ price: Number(price) });
    }

    // 3) Lokaler Fallback: materials.json
    try {
      const materialsPath = path.join(__dirname, 'materials.json');
      const raw = fs.readFileSync(materialsPath, 'utf8');
      const mats = JSON.parse(raw);
      const match = Array.isArray(mats) ? mats.find(m => m.sku === sku) : null;
      if (match && match.price != null) {
        return res.json({ price: Number(match.price) });
      }
    } catch {}

    return res.status(404).json({ error: 'SKU nicht gefunden' });
  } catch (err) {
    // Letzter Fallback bei API-Fehlern
    try {
      const materialsPath = path.join(__dirname, 'materials.json');
      const raw = fs.readFileSync(materialsPath, 'utf8');
      const mats = JSON.parse(raw);
      const match = Array.isArray(mats) ? mats.find(m => m.sku === sku) : null;
      if (match && match.price != null) {
        return res.json({ price: Number(match.price) });
      }
    } catch {}
    return res.status(500).json({ error: 'Fehler beim Preisabruf', details: err.message });
  }
});
// Admin-UI für Materialverwaltung bereitstellen
app.get('/admin/materials', (req, res) => {
  res.sendFile(path.join(__dirname, 'materials-admin.html'));
});
// Material-Router einbinden
const materialsRouter = require('./materials');
app.use('/materials', materialsRouter);
// Statische Bereitstellung der Uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
const port = process.env.PORT ? Number(process.env.PORT) : 3001;

// Speicherort für hochgeladene Dateien
// Ensure upload directories exist at startup to avoid ENOENT on first write
try {
  const uploadsDir = path.join(__dirname, 'uploads');
  const previewsDir = path.join(uploadsDir, 'previews');
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
  if (!fs.existsSync(previewsDir)) fs.mkdirSync(previewsDir, { recursive: true });
} catch (e) {
  console.warn('[init] Could not prepare upload directories:', e?.message || e);
}

const allowedMime = new Set([
  'image/jpeg',       // JPG
  'image/tiff',       // TIFF
  'application/pdf',  // PDF
  'image/svg+xml',    // SVG
  'application/postscript', // EPS (common)
  'application/eps',        // EPS (variant)
  'application/x-eps'       // EPS (variant)
]);
const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, path.join(__dirname, 'uploads'));
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + '-' + file.originalname);
    }
  }),
  limits: { fileSize: 50 * 1024 * 1024 * 1024 }, // 50 GB
  fileFilter: function (req, file, cb) {
    if (allowedMime.has(file.mimetype)) return cb(null, true);
    return cb(null, false);
  }
});

// Entfernt: doppelte CORS-Middleware (express.json() bereits weiter oben aktiviert)

app.get('/', (req, res) => {
  res.send('Backend läuft!');
});

// Health: verify ImageMagick is callable
app.get('/imagemagick/health', async (req, res) => {
  try {
    const result = await new Promise((resolve, reject) => {
      const child = execFile(magickCmd, ['-version'], { windowsHide: true }, (err, stdout, stderr) => {
        if (err) return reject({ message: err.message, code: err.code, stderr });
        resolve({ stdout, stderr });
      });
      const t = setTimeout(() => { try { child.kill('SIGKILL'); } catch {} reject({ message: 'timeout' }); }, 5000);
      child.on('exit', () => clearTimeout(t));
    });
    return res.json({ ok: true, cmd: magickCmd, version: result.stdout.split('\n')[0] || 'unknown' });
  } catch (e) {
    const details = typeof e === 'object' ? e : { message: String(e) };
    const code = details.code === 'ENOENT' ? 404 : 500;
    return res.status(code).json({ ok: false, cmd: magickCmd, error: details.message, stderr: details.stderr });
  }
});

// Health: verify Ghostscript (needed for PDF/EPS) — optional
app.get('/ghostscript/health', async (req, res) => {
  const gsCmd = 'gswin64c'; // common on 64-bit Windows; fallback will be ENOENT if missing
  try {
    const result = await new Promise((resolve, reject) => {
      const child = execFile(gsCmd, ['-version'], { windowsHide: true }, (err, stdout, stderr) => {
        if (err) return reject({ message: err.message, code: err.code, stderr });
        resolve({ stdout, stderr });
      });
      const t = setTimeout(() => { try { child.kill('SIGKILL'); } catch {} reject({ message: 'timeout' }); }, 5000);
      child.on('exit', () => clearTimeout(t));
    });
    return res.json({ ok: true, cmd: gsCmd, version: (result.stdout || result.stderr || '').trim() });
  } catch (e) {
    const details = typeof e === 'object' ? e : { message: String(e) };
    const code = details.code === 'ENOENT' ? 404 : 500;
    return res.status(code).json({ ok: false, cmd: gsCmd, error: details.message, stderr: details.stderr });
  }
});

// Diagnostics: verify ImageMagick and Ghostscript availability from backend
app.get('/health/imagemagick', async (req, res) => {
  try {
    await new Promise((resolve, reject) => {
      const child = execFile(magickCmd, ['-version'], { windowsHide: true }, (err, stdout, stderr) => {
        if (err) return reject(Object.assign(err, { stdout, stderr }));
        resolve({ stdout, stderr });
      });
      setTimeout(() => { try { child.kill('SIGKILL'); } catch {} reject(new Error('timeout')); }, 5000);
    });
    return res.json({ ok: true, path: magickCmd });
  } catch (e) {
    if (e && e.code === 'ENOENT') return res.status(500).json({ ok: false, error: 'imagemagick_missing' });
    if (String(e.message || '').includes('timeout')) return res.status(504).json({ ok: false, error: 'timeout' });
    return res.status(500).json({ ok: false, error: 'unknown', details: String(e && e.message || '') });
  }
});

app.get('/health/ghostscript', async (req, res) => {
  const cmd = process.platform === 'win32' ? ghostscriptCmd : 'gs';
  try {
    await new Promise((resolve, reject) => {
      const child = execFile(cmd, ['-version'], { windowsHide: true }, (err, stdout, stderr) => {
        if (err) return reject(Object.assign(err, { stdout, stderr }));
        resolve({ stdout, stderr });
      });
      setTimeout(() => { try { child.kill('SIGKILL'); } catch {} reject(new Error('timeout')); }, 5000);
    });
    return res.json({ ok: true, command: cmd });
  } catch (e) {
    if (e && e.code === 'ENOENT') return res.status(500).json({ ok: false, error: 'ghostscript_missing' });
    if (String(e.message || '').includes('timeout')) return res.status(504).json({ ok: false, error: 'timeout' });
    return res.status(500).json({ ok: false, error: 'unknown', details: String(e && e.message || '') });
  }
});

// Bild-Upload-Endpunkt
app.post('/upload', upload.single('wallpaper'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Ungültiger oder fehlender Upload. Erlaubte Dateitypen: JPG, TIFF, EPS, SVG, PDF.' });
  }
  console.log(`Datei hochgeladen: ${req.file.filename}`);

  // Preview erzeugen
  const uploadsDir = path.join(__dirname, 'uploads');
  const previewsDir = path.join(uploadsDir, 'previews');
  try { if (!fs.existsSync(previewsDir)) fs.mkdirSync(previewsDir, { recursive: true }); } catch {}

  const inputPath = path.join(uploadsDir, req.file.filename);
  const baseName = req.file.filename.replace(/\.[^.]+$/, '');
  const previewName = `${baseName}-preview.jpg`;
  const previewPath = path.join(previewsDir, previewName);
  let preview = null;
  const displayableInBrowser = (mt) => mt === 'image/jpeg' || mt === 'image/svg+xml';
  const isRasterOrSvg = ['image/jpeg', 'image/tiff', 'image/svg+xml'].includes(req.file.mimetype);
  const generationTimeoutMs = 60_000; // 60s

  // Try to generate preview for common image/vector types using sharp (raster) or ImageMagick for PDF/EPS
  if (isRasterOrSvg) {
    try {
      await Promise.race([
        sharp(inputPath)
          .rotate()
          .jpeg({ quality: 85 })
          .resize({ width: 2000, height: 2000, fit: 'inside', withoutEnlargement: true })
          .toFile(previewPath),
        new Promise((_, reject) => setTimeout(() => reject(new Error('preview_timeout')), generationTimeoutMs))
      ]);
      preview = `uploads/previews/${previewName}`;
    } catch (e) {
      // For JPEG/SVG we can fall back to original; for TIFF we need preview to render
      if (req.file.mimetype === 'image/tiff') {
        if (e && String(e.message).includes('preview_timeout')) {
          return res.status(504).json({ error: 'timeout' });
        }
        // Other sharp failures
        return res.status(500).json({ error: 'preview_failed' });
      }
      // For JPEG/SVG: leave preview null, use original on client
    }
  } else if ([
    'application/pdf',
    'application/postscript',
    'application/eps',
    'application/x-eps'
  ].includes(req.file.mimetype)) {
    // Attempt with ImageMagick (v7) CLI: first page -> JPEG
    try {
      await new Promise((resolve, reject) => {
        const args = (process.platform === 'win32')
          ? [
              'convert',
              '-density','150',
              `${inputPath}[0]`,
              '-quality','85',
              '-resize','2000x2000',
              previewPath
            ]
          : [
              '-density','150',
              `${inputPath}[0]`,
              '-quality','85',
              '-resize','2000x2000',
              previewPath
            ];
        // Ensure Ghostscript bin directory is available in PATH for delegate
        let childEnv = { ...process.env };
        try {
          if (process.platform === 'win32' && path.isAbsolute(ghostscriptCmd)) {
            const gsDir = path.dirname(ghostscriptCmd);
            const sep = ';';
            childEnv.PATH = `${gsDir}${sep}${childEnv.PATH || ''}`;
          }
          // Point to local policy override directory if present
          const policyDir = path.join(__dirname, 'im-policy');
          if (fs.existsSync(policyDir)) {
            const key = 'MAGICK_CONFIGURE_PATH';
            childEnv[key] = policyDir + (process.platform === 'win32' ? ';' : ':') + (childEnv[key] || '');
          }
        } catch {}
        const child = execFile(magickCmd, args, { windowsHide: true, env: childEnv }, (err, stdout, stderr) => {
          if (err) {
            try { err.stdout = stdout; } catch {}
            try { err.stderr = stderr; } catch {}
            return reject(err);
          }
          resolve();
        });
        // enforce timeout
        const t = setTimeout(() => { try { child.kill('SIGKILL'); } catch {} reject(new Error('preview_timeout')); }, generationTimeoutMs);
        child.on('exit', () => clearTimeout(t));
      });
      if (fs.existsSync(previewPath)) {
        preview = `uploads/previews/${previewName}`;
      }
    } catch (e) {
      const msg = String(e && e.message || '');
      const stderr = String(e && e.stderr || '');
      if (msg.includes('preview_timeout')) {
        return res.status(504).json({ error: 'timeout' });
      }
      // ENOENT often means executable not found; re-check the resolved path to avoid misleading users
      if (e && e.code === 'ENOENT') {
        let exists = true;
        try { exists = fs.existsSync(magickCmd); } catch { exists = true; }
        if (!exists) {
          console.error('[preview] ImageMagick binary not found at path:', magickCmd);
          return res.status(500).json({ error: 'imagemagick_missing', cmd: magickCmd, exists: false });
        }
        // If the binary exists, continue with further checks below
      }
      // Ghostscript/delegate/policy issues
      if (/no decode delegate/i.test(stderr) || /ghostscript/i.test(stderr) || /gswin64c/i.test(stderr)) {
        return res.status(500).json({ error: 'ghostscript_missing' });
      }
      if (/not authorized/i.test(stderr) && /policy/i.test(stderr)) {
        return res.status(500).json({ error: 'imagemagick_policy' });
      }
      console.error('[preview] ImageMagick conversion failed', { code: e?.code, message: e?.message, stderr });
      return res.status(500).json({ error: 'preview_failed', details: (stderr || e?.message || '').slice(0, 500) });
    }
  }
  res.json({ message: 'Datei erfolgreich hochgeladen!', filename: req.file.filename, preview });
});

// Endpunkt: Liste aller hochgeladenen Dateien
app.get('/files', (req, res) => {
  fs.readdir(path.join(__dirname, 'uploads'), (err, files) => {
    if (err) {
      return res.status(500).send('Fehler beim Lesen des Upload-Ordners.');
    }
    res.send({ files });
  });
});

// Extra diagnostics: list ImageMagick formats (filter for PDF/PS/EPS)
app.get('/health/imagemagick/formats', async (req, res) => {
  try {
    const out = await new Promise((resolve, reject) => {
      const child = execFile(magickCmd, ['-list', 'format'], { windowsHide: true }, (err, stdout, stderr) => {
        if (err) return reject({ message: err.message, stderr });
        resolve(stdout);
      });
      setTimeout(() => { try { child.kill('SIGKILL'); } catch {} reject({ message: 'timeout' }); }, 5000);
    });
    const lines = (out || '').split(/\r?\n/).filter(l => /(PDF|PS|EPS)/i.test(l));
    res.json({ ok: true, formats: lines });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e.message || e) });
  }
});

// Extra diagnostics: list ImageMagick policy rules
app.get('/health/imagemagick/policy', async (req, res) => {
  try {
    const out = await new Promise((resolve, reject) => {
      const child = execFile(magickCmd, ['-list', 'policy'], { windowsHide: true }, (err, stdout, stderr) => {
        if (err) return reject({ message: err.message, stderr });
        resolve(stdout || stderr || '');
      });
      setTimeout(() => { try { child.kill('SIGKILL'); } catch {} reject({ message: 'timeout' }); }, 5000);
    });
    res.type('text/plain').send(out);
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e.message || e) });
  }
});

app.listen(port, () => {
  console.log(`Backend läuft auf http://localhost:${port}`);
  console.log(`ImageMagick command: ${magickCmd}`);
  console.log(`Ghostscript command: ${process.platform === 'win32' ? 'gswin64c' : 'gs'}`);
});
